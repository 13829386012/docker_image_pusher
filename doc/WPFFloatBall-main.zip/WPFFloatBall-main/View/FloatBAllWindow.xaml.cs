﻿using System.Windows;
using System.Windows.Input;
using System;
using System.Windows.Media.Animation;
using System.Windows.Controls;
using System.Windows.Media;
using WPFFloatBall.View;
using System.Security.Principal;
using System.Windows.Threading;
using System.Windows.Media.Imaging; // 添加这行

namespace WPFFloatBall.View
{
    /// <summary>
    /// FloatAlarmWIndow.xaml 的交互逻辑
    /// </summary>
    public partial class FloatAlarmWIndow : Window
    {
        private bool _isMenuExpanded = false;
        private System.Windows.Point _startPoint; // 使用 System.Windows.Point
        private bool _isDragging = false;
        private Storyboard _floatingAnimation;
        private bool _isMouseOver = false;
        private Storyboard _expandMenuStoryboard;
        private Storyboard _moveButton1Storyboard;
        private Storyboard _moveButton2Storyboard;
        private Storyboard _moveButton3Storyboard;
        private DispatcherTimer _notificationTimer;
        private bool _isFirstRun = true;

        public FloatAlarmWIndow()
        {
            InitializeComponent();
            this.Width = 500;
            this.Height = 500;
            InitializeFloatingAnimation();
            InitializeMenuAnimations();
            InitializeNotification();
            
        }

        private void InitializeFloatingAnimation()
        {
            _floatingAnimation = new Storyboard();

            DoubleAnimation floatUpDown = new DoubleAnimation
            {
                From = 0,
                To = 10,
                Duration = new Duration(TimeSpan.FromSeconds(1)), // 将动画时间从2秒改为1秒使
                AutoReverse = true,
                RepeatBehavior = RepeatBehavior.Forever
            };

            Storyboard.SetTarget(floatUpDown, this);
            Storyboard.SetTargetProperty(floatUpDown, new PropertyPath("(UIElement.RenderTransform).(TranslateTransform.Y)"));

            _floatingAnimation.Children.Add(floatUpDown);

            this.RenderTransform = new TranslateTransform();
            StartFloatingAnimation();
        }

        private void InitializeMenuAnimations()
        {
            _expandMenuStoryboard = this.FindResource("ExpandMenuStoryboard") as Storyboard;
            _moveButton1Storyboard = this.FindResource("MoveButton1") as Storyboard;
            _moveButton2Storyboard = this.FindResource("MoveButton2") as Storyboard;
            _moveButton3Storyboard = this.FindResource("MoveButton3") as Storyboard;

            if (_expandMenuStoryboard == null || _moveButton1Storyboard == null || 
                _moveButton2Storyboard == null || _moveButton3Storyboard == null)
            {
                MessageBox.Show("无法加载所需的动画资源", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void InitializeNotification()
        {
            if (_isFirstRun)
            {
                string userName = Environment.UserName;
                UserNameText.Text = $"欢迎，{userName}";
                
                // 加载用户头像
                try
                {
                    string avatarPath = "pack://application:,,,/Resource/Image/logo.png";
                    BitmapImage avatarImage = new BitmapImage();
                    avatarImage.BeginInit();
                    avatarImage.UriSource = new Uri(avatarPath);
                    avatarImage.CacheOption = BitmapCacheOption.OnLoad;
                    avatarImage.CreateOptions = BitmapCreateOptions.IgnoreImageCache | BitmapCreateOptions.PreservePixelFormat;
                    avatarImage.EndInit();
                    if (avatarImage.CanFreeze) avatarImage.Freeze();
                    UserImage.Source = avatarImage;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"加载用户头像时出错: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                    // 如果加载失败，可以设置一个默认头像
                    UserImage.Source = new BitmapImage(new Uri("pack://application:,,,/Resource/Image/logo.png"));
                }

                NotificationPanel.Visibility = Visibility.Visible;

                _notificationTimer = new DispatcherTimer();
                _notificationTimer.Interval = TimeSpan.FromSeconds(30);
                _notificationTimer.Tick += NotificationTimer_Tick;
                _notificationTimer.Start();

                _isFirstRun = false;
            }
        }

        private void NotificationTimer_Tick(object sender, EventArgs e)
        {
            HideNotification();
        }

        private void HideNotification()
        {
            NotificationPanel.Visibility = Visibility.Collapsed;
            _notificationTimer.Stop();
        }

        private void StartFloatingAnimation()
        {
            if (!_isMenuExpanded && !_isDragging && !_isMouseOver)
            {
                _floatingAnimation.Begin();
            }
        }

        private void StopFloatingAnimation()
        {
            _floatingAnimation.Stop();
        }

        protected override void OnMouseEnter(MouseEventArgs e)
        {
            base.OnMouseEnter(e);
            _isMouseOver = true;
            StopFloatingAnimation();
        }

        protected override void OnMouseLeave(MouseEventArgs e)
        {
            base.OnMouseLeave(e);
            _isMouseOver = false;
            StartFloatingAnimation();
        }

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            StopFloatingAnimation();
            if (e.OriginalSource is Grid grid && grid.Name == "ExpandedMenu")
            {
                // 如果点击的是展开菜单，不做任何操作
                return;
            }

            _startPoint = e.GetPosition(this);
            _isDragging = false;
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (NotificationPanel.Visibility == Visibility.Visible)
            {
                _notificationTimer.Stop();
                _notificationTimer.Start();
            }
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                System.Windows.Point currentPosition = e.GetPosition(this);
                if ((Math.Abs(currentPosition.X - _startPoint.X) > SystemParameters.MinimumHorizontalDragDistance ||
                     Math.Abs(currentPosition.Y - _startPoint.Y) > SystemParameters.MinimumVerticalDragDistance) &&
                    !_isMenuExpanded)
                {
                    _isDragging = true;
                    DragMove();
                }
            }
        }

        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonUp(e);
            if (!_isDragging)
            {
                ToggleMenu();
            }
            _isDragging = false;
            if (!_isMenuExpanded)
            {
                StartFloatingAnimation();
            }
        }

        private void FloatBall_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // 移除此方法，因为我们现在在 OnMouseLeftButtonUp 中处理菜单切换
            e.Handled = true;
        }

        private void FloatBall_MouseEnter(object sender, MouseEventArgs e)
        {
            this.Cursor = Cursors.Hand;
        }

        private void FloatBall_MouseLeave(object sender, MouseEventArgs e)
        {
            this.Cursor = Cursors.Arrow;
        }

        private void ToggleMenu()
        {
            if (_isMenuExpanded)
            {
                // 收起菜单
                CollapseMenu();
            }
            else
            {
                // 展开菜单
                ExpandMenu();
                HideNotification(); // 添加这行
            }
            _isMenuExpanded = !_isMenuExpanded;
        }

        private void ExpandMenu()
        {
            StopFloatingAnimation();
            ExpandedMenu.Visibility = Visibility.Visible;
            
            // 强制更新布局
            ExpandedMenu.UpdateLayout();
            
            // 设置 ExpandedMenu 的 RenderTransformOrigin 为悬浮球的中心
            Point floatBallCenter = new Point(FloatBall.ActualWidth / 2, FloatBall.ActualHeight / 2);
            Point floatBallCenterInWindow = FloatBall.TransformToAncestor(this).Transform(floatBallCenter);

            // 确保 ExpandedMenu 的尺寸不为零
            if (ExpandedMenu.ActualWidth > 0 && ExpandedMenu.ActualHeight > 0)
            {
                ExpandedMenu.RenderTransformOrigin = new Point(
                    floatBallCenterInWindow.X / ExpandedMenu.ActualWidth,
                    floatBallCenterInWindow.Y / ExpandedMenu.ActualHeight
                );
            }
            else
            {
                // 如果 ExpandedMenu 尺寸为零，使用默认中心点
                ExpandedMenu.RenderTransformOrigin = new Point(0.5, 0.5);
            }

            // 重置按钮位置和透明度
            ResetButtonStates();

            // 停止所有正在进行的动画
            StopAllAnimations();

            // 开始展开动画
            _expandMenuStoryboard?.Begin();
            _moveButton1Storyboard?.Begin();
            _moveButton2Storyboard?.Begin();
            _moveButton3Storyboard?.Begin();
        }

        private void ResetButtonStates()
        {
            Button1.Opacity = 0;
            Button2.Opacity = 0;
            Button3.Opacity = 0;

            // 重置按钮的变换
            ((TransformGroup)Button1.RenderTransform).Children[0] = new ScaleTransform(1, 1, 40, 40);
            ((TransformGroup)Button1.RenderTransform).Children[1] = new TranslateTransform(0, 0);
            
            ((TransformGroup)Button2.RenderTransform).Children[0] = new ScaleTransform(1, 1, 40, 40);
            ((TransformGroup)Button2.RenderTransform).Children[1] = new TranslateTransform(0, 0);
            
            ((TransformGroup)Button3.RenderTransform).Children[0] = new ScaleTransform(1, 1, 40, 40);
            ((TransformGroup)Button3.RenderTransform).Children[1] = new TranslateTransform(0, 0);
        }

        private void StopAllAnimations()
        {
            _expandMenuStoryboard?.Stop();
            _moveButton1Storyboard?.Stop();
            _moveButton2Storyboard?.Stop();
            _moveButton3Storyboard?.Stop();
        }

        private void CollapseMenu()
        {
            // 停止所有正在进行的动画
            StopAllAnimations();

            // 收起菜单的动画
            Storyboard collapseMenu = new Storyboard();

            DoubleAnimation fadeOut = new DoubleAnimation(1, 0, new Duration(TimeSpan.FromSeconds(0.3)));
            Storyboard.SetTarget(fadeOut, ExpandedMenu);
            Storyboard.SetTargetProperty(fadeOut, new PropertyPath("Opacity"));
            collapseMenu.Children.Add(fadeOut);

            collapseMenu.Completed += (s, e) =>
            {
                ExpandedMenu.Visibility = Visibility.Collapsed;
                StartFloatingAnimation();
                ResetButtonStates();
            };

            collapseMenu.Begin();
        }

        // 新增的方法
        private void MessageCenterButton_Click(object sender, RoutedEventArgs e)
        {
            ChatWindow chatWindow = new ChatWindow();
            chatWindow.Owner = this;
            chatWindow.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            chatWindow.Show();
        }

        private void ScreenshotButton_Click(object sender, RoutedEventArgs e)
        {
            // 实现截图功能
        }

        private void TakeScreenshot(ScreenshotType type)
        {
            // 根据类型实现全屏、窗口或自由绘制截图
        }

        private void UploadScreenshot(System.Windows.Media.Imaging.BitmapSource screenshot)
        {
            // 实现截图上传功能
        }

        private void UploadScreenshot_Click(object sender, RoutedEventArgs e)
        {
            // 实现上传功能
            MessageBox.Show("上传功能待实现");
        }

        private void Analyze_Click(object sender, RoutedEventArgs e)
        {
            // 实现分析功能
        }

        private void AIAnalyze_Click(object sender, RoutedEventArgs e)
        {
            // 实现AI分析功能
            MessageBox.Show("AI分析功能待实现");
        }

        private void UserCenter_Click(object sender, RoutedEventArgs e)
        {
            if (NotificationPanel.Visibility == Visibility.Visible)
            {
                HideNotification();
            }
            else
            {
                NotificationPanel.Visibility = Visibility.Visible;
                _notificationTimer.Start();
            }
        }
    }

    public enum ScreenshotType
    {
        FullScreen,
        Window,
        Custom
    }
}
