using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Drawing;
using System.Windows.Forms;
using Point = System.Windows.Point;

namespace WPFFloatBall.View
{
    public partial class ScreenshotWindow : Window
    {
        private Point startPoint;
        private bool isDrawing = false;
        private BitmapSource fullScreenBitmap;

        public ScreenshotWindow()
        {
            InitializeComponent();
            CaptureScreen();
        }

        private void CaptureScreen()
        {
            using (var screenBmp = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height))
            {
                using (var g = Graphics.FromImage(screenBmp))
                {
                    g.CopyFromScreen(0, 0, 0, 0, screenBmp.Size);
                }
                fullScreenBitmap = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
                    screenBmp.GetHbitmap(),
                    IntPtr.Zero,
                    Int32Rect.Empty,
                    BitmapSizeOptions.FromEmptyOptions());
            }
            ScreenshotImage.Source = fullScreenBitmap;
        }

        private void ScreenshotImage_MouseDown(object sender, MouseButtonEventArgs e)
        {
            startPoint = e.GetPosition(ScreenshotImage);
            isDrawing = true;
            SelectionRectangle.Width = 0;
            SelectionRectangle.Height = 0;
            Canvas.SetLeft(SelectionRectangle, startPoint.X);
            Canvas.SetTop(SelectionRectangle, startPoint.Y);
            SelectionRectangle.Visibility = Visibility.Visible;
        }

        private void ScreenshotImage_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (isDrawing)
            {
                var currentPoint = e.GetPosition(ScreenshotImage);
                double width = Math.Abs(currentPoint.X - startPoint.X);
                double height = Math.Abs(currentPoint.Y - startPoint.Y);

                SelectionRectangle.Width = width;
                SelectionRectangle.Height = height;

                Canvas.SetLeft(SelectionRectangle, Math.Min(startPoint.X, currentPoint.X));
                Canvas.SetTop(SelectionRectangle, Math.Min(startPoint.Y, currentPoint.Y));
            }
        }

        private void ScreenshotImage_MouseUp(object sender, MouseButtonEventArgs e)
        {
            isDrawing = false;
            SaveButton.Visibility = Visibility.Visible;
            CancelButton.Visibility = Visibility.Visible;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            var rect = new Int32Rect(
                (int)Canvas.GetLeft(SelectionRectangle),
                (int)Canvas.GetTop(SelectionRectangle),
                (int)SelectionRectangle.Width,
                (int)SelectionRectangle.Height);

            var croppedBitmap = new CroppedBitmap(fullScreenBitmap, rect);

            var saveDialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "PNG Image|*.png",
                Title = "Save screenshot"
            };
            if (saveDialog.ShowDialog() == true)
            {
                var encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(croppedBitmap));
                using (var fs = System.IO.File.OpenWrite(saveDialog.FileName))
                {
                    encoder.Save(fs);
                }
            }

            this.Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}