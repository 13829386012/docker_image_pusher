using System;
using System.Windows;
using System.Windows.Input;
using Microsoft.Web.WebView2.Core;
using System.Diagnostics;

namespace WPFFloatBall.View
{
    public partial class ChatWindow : Window
    {
        private bool _isMaximized = false;

        public ChatWindow()
        {
            InitializeComponent();
            InitializeAsync();
        }

        private async void InitializeAsync()
        {
            try
            {
                var env = await CoreWebView2Environment.CreateAsync(null, null, new CoreWebView2EnvironmentOptions("--disable-web-security"));
                await ChatWebView.EnsureCoreWebView2Async(env);
                ChatWebView.CoreWebView2.Settings.AreDefaultScriptDialogsEnabled = true;
                ChatWebView.CoreWebView2.Settings.IsScriptEnabled = true;
                ChatWebView.CoreWebView2.Settings.AreDefaultContextMenusEnabled = true;
                ChatWebView.CoreWebView2.Settings.IsWebMessageEnabled = true;
                
                ChatWebView.CoreWebView2.NavigationCompleted += CoreWebView2_NavigationCompleted;
                ChatWebView.CoreWebView2.WebMessageReceived += CoreWebView2_WebMessageReceived;
                LoadChatbot();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"初始化 WebView2 时出错: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadChatbot()
        {
            try
            {
                string html = @"
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <meta charset='utf-8'>
                        <style>
                            body, html { margin: 0; padding: 0; height: 100%; overflow: hidden; }
                            iframe { width: 100%; height: 100%; border: none; }
                        </style>
                        <script>
                            window.addEventListener('message', function(event) {
                                window.chrome.webview.postMessage(JSON.stringify(event.data));
                            }, false);
                        </script>
                    </head>
                    <body>
                    <iframe
                     src=""https://test-portal.myfiinet.com/aigcweb/chatbot/sdFUb4udXIEV75Tg""
                     frameborder=""0""
                     allow=""microphone"">
                    </iframe>
                    </body>
                    </html>";

                ChatWebView.NavigateToString(html);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"加载聊天机器人时出错: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void CoreWebView2_NavigationCompleted(object sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            if (e.IsSuccess)
            {
                Debug.WriteLine("Page loaded successfully");
                await ChatWebView.ExecuteScriptAsync(@"
                    const resizeObserver = new ResizeObserver(entries => {
                        for (let entry of entries) {
                            window.chrome.webview.postMessage(JSON.stringify({type: 'resize', height: entry.contentRect.height}));
                        }
                    });
                    resizeObserver.observe(document.body);
                ");
            }
            else
            {
                Debug.WriteLine($"Page load failed with error: {e.WebErrorStatus}");
                MessageBox.Show($"页面加载失败: {e.WebErrorStatus}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CoreWebView2_WebMessageReceived(object sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            string jsonMessage = e.WebMessageAsJson;
            if (jsonMessage.Contains("\"type\":\"resize\""))
            {
                int startIndex = jsonMessage.IndexOf("\"height\":") + 9;
                int endIndex = jsonMessage.IndexOf("}", startIndex);
                if (double.TryParse(jsonMessage.Substring(startIndex, endIndex - startIndex), out double height))
                {
                    Dispatcher.Invoke(() =>
                    {
                        this.Height = height + 30; // 30 is the height of the title bar
                    });
                }
            }
        }

        private void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void MaximizeRestoreButton_Click(object sender, RoutedEventArgs e)
        {
            if (_isMaximized)
            {
                this.WindowState = WindowState.Normal;
                _isMaximized = false;
            }
            else
            {
                this.WindowState = WindowState.Maximized;
                _isMaximized = true;
            }
        }
    }

    public class WebViewMessage
    {
        public string Type { get; set; }
        public double Height { get; set; }
    }
}