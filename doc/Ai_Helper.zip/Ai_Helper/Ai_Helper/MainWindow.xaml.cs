﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace Ai_Helper
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool isMenuExpanded = false;
        private bool isDragging = false;
        private Point startPoint;
        private Point buttonStartPoint;

        public MainWindow()
        {
            InitializeComponent();
            PositionFloatingButtonAtBottomRight();

            // 使整个窗口透明，允许鼠标事件穿透
            this.Background = Brushes.Transparent;
            this.AllowsTransparency = true;
        }

        private void PositionFloatingButtonAtBottomRight()
        {
            double screenWidth = SystemParameters.PrimaryScreenWidth;
            double screenHeight = SystemParameters.PrimaryScreenHeight;

            // 设置悬浮球的初始位置
            Canvas.SetLeft(FloatingButton, screenWidth - FloatingButton.Width - 20);
            Canvas.SetTop(FloatingButton, screenHeight - FloatingButton.Height - 20);
        }

        private void FloatingButton_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                Point currentPosition = e.GetPosition(this);
                if (!isDragging && (Math.Abs(currentPosition.X - startPoint.X) > SystemParameters.MinimumHorizontalDragDistance ||
                                    Math.Abs(currentPosition.Y - startPoint.Y) > SystemParameters.MinimumVerticalDragDistance))
                {
                    isDragging = true;
                }

                if (isDragging)
                {
                    Vector offset = currentPosition - startPoint;
                    double newLeft = buttonStartPoint.X + offset.X;
                    double newTop = buttonStartPoint.Y + offset.Y;

                    // 确保悬浮球不会完全移出屏幕
                    newLeft = Math.Max(-FloatingButton.Width / 2, Math.Min(newLeft, SystemParameters.PrimaryScreenWidth - FloatingButton.Width / 2));
                    newTop = Math.Max(-FloatingButton.Height / 2, Math.Min(newTop, SystemParameters.PrimaryScreenHeight - FloatingButton.Height / 2));

                    Canvas.SetLeft(FloatingButton, newLeft);
                    Canvas.SetTop(FloatingButton, newTop);

                    // 如果菜单是展开的，更新菜单位置
                    if (isMenuExpanded)
                    {
                        UpdateMenuPosition();
                    }

                    e.Handled = true;
                }
            }
        }

        private void FloatingButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isDragging)
            {
                isMenuExpanded = !isMenuExpanded;
                MenuPanel.Visibility = isMenuExpanded ? Visibility.Visible : Visibility.Collapsed;
                if (isMenuExpanded)
                {
                    UpdateMenuPosition();
                }
            }
        }

        private void UpdateMenuPosition()
        {
            double buttonLeft = Canvas.GetLeft(FloatingButton);
            double buttonTop = Canvas.GetTop(FloatingButton);

            // 根据屏幕边界调整菜单位置
            if (buttonLeft + FloatingButton.Width + MenuPanel.ActualWidth > SystemParameters.PrimaryScreenWidth)
            {
                Canvas.SetLeft(MenuPanel, buttonLeft - MenuPanel.ActualWidth);
            }
            else
            {
                Canvas.SetLeft(MenuPanel, buttonLeft + FloatingButton.Width);
            }

            Canvas.SetTop(MenuPanel, buttonTop);
        }

        private void ScreenshotButton_Click(object sender, RoutedEventArgs e)
        {
            // 实现截图功能
            MessageBox.Show("截图功能待实现");
        }

        private void UploadButton_Click(object sender, RoutedEventArgs e)
        {
            // 实现上传功能
            MessageBox.Show("上传功能待实现");
        }

        private void AnalyzeButton_Click(object sender, RoutedEventArgs e)
        {
            // 实现分析功能
            MessageBox.Show("分析功能待实现");
        }

        private void MessageCenterButton_Click(object sender, RoutedEventArgs e)
        {
            // 实现消息中心功能
            MessageBox.Show("消息中心功能待实现");
        }

        public void SimulateException()
        {
            // 模拟异常情况，使按钮闪烁
            var blinkAnimation = new ColorAnimation(
                Colors.Blue, Colors.Red, new Duration(TimeSpan.FromSeconds(0.5)))
            {
                AutoReverse = true,
                RepeatBehavior = RepeatBehavior.Forever
            };
            FloatingButton.Background.BeginAnimation(SolidColorBrush.ColorProperty, blinkAnimation);
        }

        private void FloatingButton_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isDragging = false;  // 初始化为 false
            startPoint = e.GetPosition(this);
            buttonStartPoint = new Point(Canvas.GetLeft(FloatingButton), Canvas.GetTop(FloatingButton));
            ((UIElement)sender).CaptureMouse();
            e.Handled = true;
        }

        private void FloatingButton_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            ((UIElement)sender).ReleaseMouseCapture();
            if (!isDragging)
            {
                // 如果不是拖拽，则执行点击操作
                FloatingButton_Click(sender, e);
            }
            isDragging = false;
            e.Handled = true;
        }

        private void FloatingButton_MouseEnter(object sender, MouseEventArgs e)
        {
            // 鼠标进入时的额外逻辑（如果需要）
            this.Cursor = Cursors.Hand; // 改变鼠标样式为手型
        }

        private void FloatingButton_MouseLeave(object sender, MouseEventArgs e)
        {
            // 鼠标离开时的额外逻辑（如果需要）
            this.Cursor = Cursors.Arrow; // 恢复默认鼠标样式
        }
    }
}
