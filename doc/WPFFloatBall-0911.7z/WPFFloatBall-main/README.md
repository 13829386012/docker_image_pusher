# WPFFloatBall
一个由WPF创建的透明无边框悬浮球（Transparent borderless floating ball created by WPF）


![VeryCapture_20220512134333](https://user-images.githubusercontent.com/31178959/168000148-8bf5802d-617c-4c14-8794-66a148ec61c4.gif)
