﻿using System.Windows;
using System.Drawing; // Added for Bitmap
using System.Windows.Input;
using System;
using System.Windows.Media.Animation;
using System.Windows.Controls;

namespace WPFFloatBall.View
{
    /// <summary>
    /// FloatAlarmWIndow.xaml 的交互逻辑
    /// </summary>
    public partial class FloatAlarmWIndow : Window
    {
        private System.Windows.Threading.DispatcherTimer _timer;
        private bool _isMenuExpanded = false;

        public FloatAlarmWIndow()
        {
            InitializeComponent();
            InitializeTimer();
        }

        private void InitializeTimer()
        {
            _timer = new System.Windows.Threading.DispatcherTimer();
            _timer.Tick += Timer_Tick;
            _timer.Interval = TimeSpan.FromMinutes(5); // 每5分钟检查一次
            _timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            CheckAndPushNotifications();
        }

        private void CheckAndPushNotifications()
        {
            // 检查待办事项并推送消息
        }

        private void ScreenshotButton_Click(object sender, RoutedEventArgs e)
        {
            // 实现截图功能
        }

        private void TakeScreenshot(ScreenshotType type)
        {
            // 根据类型实现全屏、窗口或自由绘制截图
        }

        private void UploadScreenshot(Bitmap screenshot)
        {
            // 实现截图上传功能
        }

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            if (e.OriginalSource is Grid grid && grid.Name == "ExpandedMenu")
            {
                // 如果点击的是展开菜单，不做任何��作
                return;
            }

            if (e.ClickCount == 1)
            {
                if (_isMenuExpanded)
                {
                    CollapseMenu();
                }
                else
                {
                    ExpandMenu();
                }
            }
            
            // 无论是单击还是双击，都允许拖动
            this.DragMove();
        }

        private void ExpandMenu()
        {
            ExpandedMenu.Visibility = Visibility.Visible;
            var storyboard = (Storyboard)FindResource("ExpandMenuStoryboard");
            storyboard.Begin();
            _isMenuExpanded = true;
            this.Width = 200; // 展开时将窗口宽度设置为200
        }

        private void CollapseMenu()
        {
            var storyboard = (Storyboard)FindResource("ExpandMenuStoryboard");
            storyboard.Stop();
            ExpandedMenu.Visibility = Visibility.Collapsed;
            _isMenuExpanded = false;
            this.Width = 100; // 收起时将窗口宽度设置回100
        }

        // 新增的方法
        private void MessageCenterButton_Click(object sender, RoutedEventArgs e)
        {
            // 实现消息中心功能
        }

        private void Screenshot_Click(object sender, RoutedEventArgs e)
        {
            // 实现截图功能
            MessageBox.Show("实现截图功能");
        }

        private void Upload_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("实现上传功能");
            // 实现上传功能
        }

        private void Analyze_Click(object sender, RoutedEventArgs e)
        {
            // 实现分析功能
        }
    }

    public enum ScreenshotType
    {
        FullScreen,
        Window,
        Custom
    }
}
